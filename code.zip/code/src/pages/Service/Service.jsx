
const Service = () => {
    return (
        <div>
            <h1>Service</h1>
        </div>
    );
};

export default Service;